import React from 'react';

function Contact() {
  return (
    <div>
        <h1>I AM Contact PAGE!!!</h1>
    </div>
  );
}

export default Contact;