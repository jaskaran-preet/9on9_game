import React from 'react';

function About() {
  return (
    <div>
        <h1>I AM ABOUT PAGE!!!</h1>
    </div>
  );
}

export default About;